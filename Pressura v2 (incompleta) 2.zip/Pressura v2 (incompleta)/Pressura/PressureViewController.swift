//
//  PressureViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

var sistolica = [Double]()
var diastolica = [Double]()
var medida = 0

class PressureViewController: UIViewController {

    @IBOutlet weak var tfMedSup: UITextField!
    
    @IBOutlet weak var tfMedInf: UITextField!
    
    @IBOutlet weak var btSiguiente: UIButton!
    
    @IBOutlet weak var btFin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func btSiguienteSend(_ sender: UIButton) {
    }
    
    
    
    @IBAction func btFinalizarSend(_ sender: UIButton) {
    }
    
    func disableButton(_ sender: Any?)
    {
        if (medida == 3)
        {
            btSiguiente.isEnabled = false
        }
    }
    
    
    func addToArray(_ sender: UIButton)
    {
        if(sender.tag == 1)
        {
            if (!tfMedSup.text!.isEmpty && !tfMedInf.text!.isEmpty )
            {
                sistolica.append(Double(tfMedSup.text!)!)
                diastolica.append(Double(tfMedInf.text!)!)
                medida += medida
            }
            else
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de ingresar ambas medidas", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }
        }
        
        
    }
    
    func prepare(for segue: UIStoryboardSegue, sender: UIButton)
    {
        if(sender.tag == 0)
        {
            medida = 0
            if (segue.identifier == "sendData")
            {
            
            }
        }
      
    }
    
    
}

//
//  TimerViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

class TimerViewController: UIViewController {
/*
    @IBOutlet weak var lbTimer: UILabel!
    
    var count = 60
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        var timer = Timer.scheduledTimer(timeInterval: 0.4, target: self, selector: #selector(UIMenuController.update), userInfo: nil, repeats: true)
        
    }
    

   func update()
    {
        if(count > 0)
        {
            lbTimer.text = String(count -= count)
        }
    }
*/
}

//
//  ConfirmViewController.swift
//  Pressura
//
//  Created by alumno on 28/09/22.
//

import UIKit

class ConfirmViewController: UIViewController {
    
    @IBOutlet weak var tfEstadoCorp: UITextField!
    
    @IBOutlet weak var tfMed1Sup: UITextField!
    
    @IBOutlet weak var tfMed1Inf: UITextField!
    
    @IBOutlet weak var tfMed2Sup: UITextField!
    
    @IBOutlet weak var tfMed2Inf: UITextField!
    
    @IBOutlet weak var tfMed3Sup: UITextField!
    
    @IBOutlet weak var tfMed3Inf: UITextField!
    
    @IBOutlet weak var btEnviarMed: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func enviarDatos(_ sender: UIButton) {
        //enviar datos a base de datos
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func desplegarDatos()
    {
        //Desplegar datos en los text fields respectivos
    }
    
    
    
}

//
//  ConfigurationViewController.swift
//  Pressura
//
//  Created by alumno on 01/10/22.
//

import UIKit

class ConfigurationViewController: UIViewController {
    
    @IBOutlet weak var btBack: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    

}

//
//  ProfileViewController.swift
//  Pressura
//
//  Created by alumno on 01/10/22.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var tfName: UITextField!
    
    @IBOutlet weak var dpDateofBirth: UIDatePicker!
    
    @IBOutlet weak var tfSex: UITextField!
    
    @IBOutlet weak var tfAge: UITextField!
    
    @IBOutlet weak var tfHeight: UITextField!
    
    @IBOutlet weak var tfWeight: UITextField!
    
    @IBOutlet weak var tfAddress: UITextField!
    
    @IBOutlet weak var tfEmail: UITextField!
    
    @IBOutlet weak var tfDoctors: UITextField!
    
    @IBOutlet weak var btEdit: UIButton!
    
    @IBOutlet weak var btBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func editAndSave(_ sender: UIButton)
    {
        editProfile()
    }
    
    func editProfile()
    {
        //al picar boton entrar en modo editar y al picarle de nuevo, guardar cambios
    }
 
    
    
    
}

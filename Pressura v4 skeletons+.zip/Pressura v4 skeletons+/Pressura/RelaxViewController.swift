//
//  RelaxViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

class RelaxViewController: UIViewController {

    @IBOutlet weak var btSendState: UIButton!
    
    @IBOutlet weak var slGBState: UISlider!
    
    @IBOutlet weak var slRelaxstate: UISlider!
    
    @IBOutlet weak var btBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func gBStateSet(_ sender: UISlider)
    {
       hardSetState()
    }
    
    @IBAction func relaxStateSet(_ sender: UISlider)
    {
        hardSetState()
    }
    
    @IBAction func sendState(_ sender: UIButton)
    {
        registerState()
    }
    
    
    func hardSetState()
    {
        //Función para que los sliders solo puedan tener 3 medidas (Min, mid, max)
    }
    
    
    func registerState ()
    {
        //Click en enviar y enviar resultados a base
    }

}

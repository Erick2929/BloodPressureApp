//
//  ConfirmViewController.swift
//  Pressura
//
//  Created by alumno on 28/09/22.
//

import UIKit
import Firebase

class ConfirmViewController: UIViewController {
    
    @IBOutlet weak var tfEstadoCorp: UITextField!
    
    @IBOutlet weak var tfRelajado: UITextField!
    
    @IBOutlet weak var tfMed1Sup: UITextField!
    
    @IBOutlet weak var tfMed1Inf: UITextField!
    
    @IBOutlet weak var tfMed2Sup: UITextField!
    
    @IBOutlet weak var tfMed2Inf: UITextField!
    
    @IBOutlet weak var tfMed3Sup: UITextField!
    
    @IBOutlet weak var tfMed3Inf: UITextField!
    
    @IBOutlet weak var btEnviarMed: UIButton!
    
    var sistolica : [Double]!
    var diastolica : [Double]!
    
    var animo : Double!
    var relajado : Double!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tfEstadoCorp.text = "\(animo*100)%"
        tfRelajado.text = "\(relajado*100)%"
        tfMed1Sup.text = "\(sistolica[0])"
        tfMed1Inf.text = "\(diastolica[0])"
        tfMed2Sup.text = "\(sistolica[1])"
        tfMed2Inf.text = "\(diastolica[1])"
        tfMed3Sup.text = "\(sistolica[2])"
        tfMed3Inf.text = "\(diastolica[2])"
    }
    
    func datos(ani:Double, rel:Double, sis:[Double], dia:[Double]) {
        animo = ani
        relajado = rel
        sistolica = sis
        diastolica = dia
    }
    
    @IBAction func enviarDatos(_ sender: UIButton) {
        //enviar datos a base de datos
        
        let db = Firestore.firestore()
        
        let now = Date()
        let stamp = Timestamp(date: now)
        
        var relaBool : Bool
        
        if relajado > 0.6 {
            relaBool = true
        }else{
            relaBool = false
        }
        
        var promedioSupe : Double = 0
        var promedioInfe : Double = 0

        print("here")
        
        for valSupe in sistolica {
            promedioSupe = promedioSupe + valSupe
        }
        
        print("there")

        
        for valInfe in diastolica {
            promedioInfe = promedioInfe + valInfe
        }
        
        print("where")

        
        promedioInfe = promedioInfe / Double(diastolica.count)
        
        promedioSupe = promedioSupe / Double(sistolica.count)
        
        let docData: [String: Any] = [
            "EstadoEmocional": "\(animo*100)%",
            "Fecha": stamp,
            "IDPaciente": UserDefaults.standard.string(forKey: "usuario")!,
            "MedidaInferior": promedioInfe,
            "MedidaSuperior": promedioSupe,
            "Relajado": relaBool
        ]
        
        var ref: DocumentReference? = nil
        ref = db.collection("Presion").addDocument(data: docData) { err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(ref!.documentID)")
                if let first = self.presentingViewController, let second = first.presentingViewController, let third = second.presentingViewController{
                    first.view.isHidden = true
                    second.view.isHidden = true
                    third.dismiss(animated: true)
                }
            }
        }
        
        
    }
    
    func desplegarDatos()
    {
        //Desplegar datos en los text fields respectivos
    }
    
    @IBAction func reiniciarToma(_ sender: UIButton) {
        if let first = presentingViewController, let second = first.presentingViewController{
            first.view.isHidden = true
            second.dismiss(animated: true)
        }
    }
    
    
}

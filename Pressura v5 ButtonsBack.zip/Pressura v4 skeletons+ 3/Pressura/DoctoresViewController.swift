//
//  DoctoresViewController.swift
//  Pressura
//
//  Created by alumno on 10/10/22.
//

import UIKit

class DoctoresViewController: UIViewController {
    
    
    @IBOutlet weak var btAddDoc: UIButton!
    
    @IBOutlet weak var btBack: UIButton!
    
    var doctores = [String]()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let celdas = tableView.dequeueReusableCell(withIdentifier: "celda")!
        celdas.textLabel?.text = doctores[indexPath.row]
        return celdas
    }
    
    
    @IBAction func goBack(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
}

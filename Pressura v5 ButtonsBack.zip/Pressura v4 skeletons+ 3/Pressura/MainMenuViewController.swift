//
//  MainMenuViewController.swift
//  Pressura
//
//  Created by Roberto Pérez Iga on 21/09/22.
//

import UIKit
import FirebaseAuth

class MainMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    func imprimirResultado(result:String){
        print(result)
    }
    
    @IBAction func signOut(_ sender: UIButton) {
        logOut(completion: imprimirResultado(result:))
    }
    
    func logOut(completion:@escaping (String)->Void){
        do{
            try Auth.auth().signOut()
            completion("OK")
            UserDefaults.standard.setValue(nil, forKey: "usuario")
            self.performSegue(withIdentifier: "Logout", sender: nil)
        }catch{
            completion("error al cerrar sesion")
            
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

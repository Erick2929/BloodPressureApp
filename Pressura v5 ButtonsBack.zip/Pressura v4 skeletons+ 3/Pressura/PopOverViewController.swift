//
//  PopOverViewController.swift
//  Pressura
//
//  Created by alumno on 10/10/22.
//

import UIKit

class PopOverViewController: UIViewController {

    @IBOutlet weak var tfDocEmail: UITextField!
    @IBOutlet weak var btSend: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        preferredContentSize = CGSize(width: 305, height: 175)
        
    }
    
    @IBAction func sendEmail(_ sender: UIButton)
    {
        //Enviar correo de doc
        dismiss(animated: true)
    }
    
}

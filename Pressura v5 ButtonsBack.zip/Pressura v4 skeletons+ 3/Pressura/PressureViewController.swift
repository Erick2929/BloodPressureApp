//
//  PressureViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

var sistolica = [Double]()
var diastolica = [Double]()
var medida = 0


class PressureViewController: UIViewController {

    @IBOutlet weak var tfMedSup: UITextField!
    
    @IBOutlet weak var tfMedInf: UITextField!
        
    @IBOutlet weak var btSiguiente: UIButton!
    
    @IBOutlet weak var btFin: UIButton!
    
    @IBOutlet weak var segMedidas: UISegmentedControl!
    
    var animo : Double!
    var relajado : Double!
    
    
    @IBOutlet weak var btRegresar: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func tapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    
    @IBAction func Regresar(_ sender: UIButton) {
        if let first = presentingViewController, let second = first.presentingViewController{
            first.view.isHidden = true
            second.dismiss(animated: true)
        }
    }
    
    @IBAction func btSiguienteSend(_ sender: UIButton) {
        addToArray()
        print(animo)
        print(relajado)
    }
    
    func datos(ani:Double, rel:Double) {
        animo = ani
        relajado = rel
    }

    
    func addToArray()
    {
            if (!tfMedSup.text!.isEmpty && !tfMedInf.text!.isEmpty )
            {
                sistolica.append(Double(tfMedSup.text!)!)
                diastolica.append(Double(tfMedInf.text!)!)
                
                tfMedSup.text = ""
                tfMedInf.text = ""
                
                if sistolica.count == 2
                {
                    btSiguiente.isEnabled = false
                    btFin.isEnabled = true
                }
                 if sistolica.count < 3
                {
                    segMedidas.selectedSegmentIndex = 1
                    self.performSegue(withIdentifier: "crono", sender: nil)
                }
                
            }
            else
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de ingresar ambas medidas", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(sistolica.count < 3)
        {
            segMedidas.selectedSegmentIndex = sistolica.count
            
        }
        if segue.identifier == "sendData"{
            let vistaConfirm = segue.destination as! ConfirmViewController
            /*vistaConfirm.tfEstadoCorp.text = "\(animo*100)%"
            vistaConfirm.tfRelajado.text = "\(relajado*100)%"
            vistaConfirm.tfMed1Sup.text = "\(sistolica[0])"
            vistaConfirm.tfMed1Inf.text = "\(diastolica[0])"
            vistaConfirm.tfMed2Sup.text = "\(sistolica[1])"
            vistaConfirm.tfMed2Inf.text = "\(diastolica[1])"
            vistaConfirm.tfMed3Sup.text = "\(sistolica[2])"
            vistaConfirm.tfMed3Inf.text = "\(diastolica[2])"
             */
            vistaConfirm.animo = animo
            vistaConfirm.relajado = relajado
            vistaConfirm.diastolica = diastolica
            vistaConfirm.sistolica = sistolica
            
        }
      
    }
    
    func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
    
}

//
//  LogInViewController.swift
//  Pressura
//
//  Created by Roberto Pérez Iga on 21/09/22.
//

import UIKit
import FirebaseAuth

class LogInViewController: UIViewController {
    @IBOutlet weak var tfCorreo: UITextField!
    {
        didSet
        {
            tfCorreo.tintColor = UIColor.lightGray
            tfCorreo.setIcon(UIImage(systemName: "envelope.fill")!)
        }
    }
    @IBOutlet weak var tfContraseña: UITextField!
    {
        didSet
        {
            tfContraseña.tintColor = UIColor.lightGray
            tfContraseña.setIcon(UIImage(systemName: "asterisk")!)
        }
    }
    
    @IBOutlet weak var btLogIn: UIButton!
    @IBOutlet weak var btRegistroSwitch: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
  
    func alarma(mensaje:String)
        {
        let alerts = UIAlertController(title: "Error", message: mensaje, preferredStyle: .alert)
        let accion = UIAlertAction(title: "OK", style: .cancel)
        alerts.addAction(accion)
        present(alerts, animated: true)
        }

    func imprimirResultado(result:String){
        print(result)
    }
    
    func login(email:String,pass:String,completion:@escaping (String)->Void){
        Auth.auth().signIn(withEmail: email, password: pass){
            (user,error) in
            if let error = error{
                if error.localizedDescription == "The password is invalid or the user does not have a password."{
                    self.alarma(mensaje: "El correo o la contraseña ingresada estan incorrectas")
                }
                completion(error.localizedDescription)
                
            }else{
                completion("OK")
                UserDefaults.standard.setValue(self.tfCorreo.text, forKey: "usuario")
                self.tfCorreo.text = ""
                self.tfContraseña.text = ""
                self.performSegue(withIdentifier: "mainI", sender: nil)
            }
        }
    }
    
    @IBAction func enviado(_ sender: UIButton)
    {
       
        let correo = tfCorreo.text
        let contraseña = tfContraseña.text
       
            if correo == ""
            {
                alarma(mensaje: "Favor de ingresar su correo")
            }
        
            else if !isValidEmail(correo!){
                alarma(mensaje: "Favor de ingresar un correo valido")
            }

            else if contraseña == ""
            {
            alarma(mensaje: "Favor de ingresar su contraseña")
            } else{
                login(email: correo!, pass: contraseña!, completion: imprimirResultado(result:))
        }
       
    }
}

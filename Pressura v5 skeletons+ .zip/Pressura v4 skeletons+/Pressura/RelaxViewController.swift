//
//  RelaxViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

class RelaxViewController: UIViewController {

    
    @IBOutlet weak var slGBState: UISlider!
    
    @IBOutlet weak var slRelaxstate: UISlider!
    
    @IBOutlet weak var btBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vistaPressure = segue.destination as! PressureViewController
        vistaPressure.animo = Double(slGBState.value)
        vistaPressure.relajado = Double(slRelaxstate.value)
        print(Double(slGBState.value))
        print(Double(slRelaxstate.value))
        
    }


}

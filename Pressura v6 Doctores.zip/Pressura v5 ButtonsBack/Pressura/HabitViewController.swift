//
//  HabitViewController.swift
//  Pressura
//
//  Created by alumno on 10/10/22.
//

import UIKit

class HabitViewController: UIViewController {

    @IBOutlet weak var slDieta: UISlider!
    
    @IBOutlet weak var slEjercicio: UISlider!
    
    @IBOutlet weak var slMeds: UISlider!
    
    @IBOutlet weak var btEnviar: UIButton!
    
    @IBOutlet weak var btBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func enviarDatos(_ sender: UIButton)
    {
       //Funcion para enviar datos
    }
    
    @IBAction func goBack(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    


}

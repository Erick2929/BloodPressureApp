//
//  DoctorTableViewCell.swift
//  Pressura
//
//  Created by Alumno on 11/10/22.
//

import UIKit

protocol DoctorTableViewCellDeligate: AnyObject {
    func didTapCancel(with row: Int)
    func didTapAccept(with row: Int)
}

class DoctorTableViewCell: UITableViewCell {
    
    weak var delegate: DoctorTableViewCellDeligate?

    static let identifier = "DoctorTableViewCell"
    
    static func nib() -> UINib{
        return UINib(nibName: "DoctorTableViewCell", bundle: nil)
    }
    
    @IBOutlet var button : UIButton!
    
    @IBOutlet var button2 : UIButton!
    
    @IBOutlet var nombre : UILabel!
    
    @IBOutlet var correo : UILabel!
    
    var row : Int = 0
    
    @IBAction func didTapButtonCancel(){
        delegate?.didTapCancel(with: row)
    }
    
    @IBAction func didTapButtonConfirm(){
        delegate?.didTapAccept(with: row)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        button.setTitleColor(.link, for: .normal)
        button2.setTitleColor(.link, for: .normal)

    }

    func configue(title: String, title2:String, relacion:Int, row:Int){
        if relacion == 1 {
            nombre.text = "Pendiente confirmación"
            correo.text = title
            button.isHidden = true
        }else if relacion == 2 {
            nombre.text = "Solicitud para compartir"
            correo.text = "\(title)"
            button.isHidden = false
        } else{
            nombre.text = title2
            correo.text = title
            button.isHidden = true
        }
        print(relacion)
        self.row = row
    }
    
}

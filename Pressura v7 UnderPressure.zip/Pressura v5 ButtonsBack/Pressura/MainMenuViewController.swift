//
//  MainMenuViewController.swift
//  Pressura
//
//  Created by Roberto Pérez Iga on 21/09/22.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class MainMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    func imprimirResultado(result:String){
        print(result)
    }
    
    @IBAction func signOut(_ sender: UIButton) {
        logOut(completion: imprimirResultado(result:))
    }
    
    func logOut(completion:@escaping (String)->Void){
        do{
            try Auth.auth().signOut()
            completion("OK")
            UserDefaults.standard.setValue(nil, forKey: "usuario")
            self.performSegue(withIdentifier: "Logout", sender: nil)
        }catch{
            completion("error al cerrar sesion")
            
        }
    }
    
    
    @IBAction func vistaDoctor(_ sender: UIButton) {
        
        var doctores = [String]()
        var doctoresNombres = [String]()
        var relacion = [Int]()
        var idDocumentos = [String]()
        
    
            let db = Firestore.firestore()
            
            db.collection("PacienteConDoctores").whereField("IDPaciente", isEqualTo: UserDefaults.standard.string(forKey: "usuario")!).getDocuments(){ [self]
                (QuerySnapshot, err) in
                if let err = err{
                    print("Error getting documents: \(err)")
                }else{
                    guard let _ = QuerySnapshot else{
                        print("Unknown Error")
                        return
                    }
                    for document in QuerySnapshot!.documents{
                        let data = document.data()
                        let IDDoc = data["IDDoctor"] as? String
                        let NomPac = data["NombreDoctor"] as? String
                        let Rela = data["Relacion"] as? Int
                        let DocumentID = document.documentID as String
                        print(IDDoc)
                        doctores.append(IDDoc!)
                        doctoresNombres.append(NomPac!)
                        relacion.append(Rela!)
                        idDocumentos.append(DocumentID)
                        
                    }
                    UserDefaults.standard.setValue(doctores, forKey: "MyDoc")
                    print(doctoresNombres)
                    UserDefaults.standard.setValue(doctoresNombres, forKey: "MyDocNom")
                    UserDefaults.standard.setValue(relacion, forKey: "MyDocRel")
                    UserDefaults.standard.setValue(idDocumentos, forKey: "MyDocIDs")
                    
                    self.performSegue(withIdentifier: "doc", sender: nil)
                }
                
            }
            
        
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                    
            
        }
    
    

}

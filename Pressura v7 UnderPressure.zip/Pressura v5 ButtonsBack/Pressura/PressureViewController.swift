//
//  PressureViewController.swift
//  Pressura
//
//  Created by alumno on 27/09/22.
//

import UIKit

var sistolica = [Double]()
var diastolica = [Double]()
var medida = 0


class PressureViewController: UIViewController {

    @IBOutlet weak var tfMedSup: UITextField!
    
    @IBOutlet weak var tfMedInf: UITextField!
        
    @IBOutlet weak var btSiguiente: UIButton!
    
    @IBOutlet weak var btFin: UIButton!
    
    @IBOutlet weak var segMedidas: UISegmentedControl!
    
    var animo : Double!
    var relajado : Double!
    
    
    @IBOutlet weak var btRegresar: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sistolica = [Double]()
        diastolica = [Double]()
    }
    @IBAction func tapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
    }
    
    
    @IBAction func Regresar(_ sender: UIButton) {
        if let first = presentingViewController, let second = first.presentingViewController{
            first.view.isHidden = true
            second.dismiss(animated: true)
        }
    }
    
    @IBAction func btSiguienteSend(_ sender: UIButton) {
        addToArray()
    }
    
    func datos(ani:Double, rel:Double) {
        animo = ani
        relajado = rel
    }

    
    func addToArray()
    {
            if (!tfMedSup.text!.isEmpty && !tfMedInf.text!.isEmpty )
            {
                if Double(tfMedSup.text!)! < 0 || Double(tfMedInf.text!)! < 0 {
                    let alerts = UIAlertController(title: "Error", message: "Favor de valores mayores a 0", preferredStyle: .alert)
                    let accion = UIAlertAction(title: "OK", style: .cancel)
                    alerts.addAction(accion)
                    present(alerts, animated: true)
                }  else if (Double(tfMedSup.text!)! <= Double(tfMedInf.text!)! ){
                    let alerts = UIAlertController(title: "Error", message: "Favor de asegurar que la Medida Superior sea mayor a la Medida Inferior", preferredStyle: .alert)
                    let accion = UIAlertAction(title: "OK", style: .cancel)
                    alerts.addAction(accion)
                    present(alerts, animated: true)
                }else{
                    sistolica.append(Double(tfMedSup.text!)!)
                    diastolica.append(Double(tfMedInf.text!)!)
                    
                    tfMedSup.text = ""
                    tfMedInf.text = ""
                    
                    
                    
                    if sistolica.count == 2
                    {
                        btSiguiente.isEnabled = false
                        btFin.isEnabled = true
                    }
                     if sistolica.count < 3
                    {
                        segMedidas.selectedSegmentIndex = 1
                         btFin.isEnabled = true
                        self.performSegue(withIdentifier: "crono", sender: nil)
                    }
                }
            }
            else
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de ingresar ambas medidas", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
        }
    }
    
    
    @IBAction func addToArrayAndExit(_ sender: UIButton) {
        
        if (!tfMedSup.text!.isEmpty && !tfMedInf.text!.isEmpty )
        {
            if Double(tfMedSup.text!)! < 0 || Double(tfMedInf.text!)! < 0 {
                let alerts = UIAlertController(title: "Error", message: "Favor de valores mayores a 0", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            } else {
                sistolica.append(Double(tfMedSup.text!)!)
                diastolica.append(Double(tfMedInf.text!)!)
                
                tfMedSup.text = ""
                tfMedInf.text = ""
                
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(sistolica.count < 3)
        {
            segMedidas.selectedSegmentIndex = sistolica.count
            
        }
        if segue.identifier == "sendData"{
            let vistaConfirm = segue.destination as! ConfirmViewController

            vistaConfirm.animo = animo
            vistaConfirm.relajado = relajado
            vistaConfirm.diastolica = diastolica
            vistaConfirm.sistolica = sistolica
            
        }
      
    }
    
    func dismissKeyboard()
    {
        view.endEditing(true)
    }
    
    
}

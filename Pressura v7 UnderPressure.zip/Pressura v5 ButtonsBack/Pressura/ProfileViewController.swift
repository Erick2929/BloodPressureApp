//
//  ProfileViewController.swift
//  Pressura
//
//  Created by alumno on 01/10/22.
//

import UIKit
import Firebase

class ProfileViewController: UIViewController {

    @IBOutlet weak var tfName: UITextField!
    
    @IBOutlet weak var dpDateofBirth: UIDatePicker!
    
    @IBOutlet weak var Sexo: UISegmentedControl!
        
    @IBOutlet weak var tfHeight: UITextField!
    
    @IBOutlet weak var tfWeight: UITextField!
    
    @IBOutlet weak var tfAddress: UITextField!
    
    @IBOutlet weak var tfEmail: UITextField!
    
    @IBOutlet weak var tfDoctors: UITextField!
    
    @IBOutlet weak var btEdit: UIButton!
    
    @IBOutlet weak var btBack: UIButton!
    
    var idDoc : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()

    }
    
    @IBAction func back(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func editAndSave(_ sender: UIButton)
    {
        editProfile()
    }
    
    func editProfile()
    {
        //al picar boton entrar en modo editar y al picarle de nuevo, guardar cambios
        let db = Firestore.firestore()
        db.collection("Paciente").document(idDoc!).updateData([
            "Altura": Double(tfHeight.text!),
            "CorreoElectronico": String(tfEmail.text!),
            "Direccion": tfAddress.text,
            "FechaNacimiento": dpDateofBirth.date,
            "IDPaciente":  String(tfEmail.text!),
            "Nombre": String(self.tfName.text!),
            "Peso": Double(tfWeight.text!),
            "Sexo": Sexo.selectedSegmentIndex
        ]){err in
            if let err = err {
                print("Error update document: \(err)")
            }else{
                UserDefaults.standard.setValue(String(self.tfName.text!), forKey: "nombre")
                self.dismiss(animated: true)
            }
        }
    }
 
    func getData() {
        var information : [String:Any]?
        let db = Firestore.firestore()
        
        db.collection("Paciente").whereField("IDPaciente", isEqualTo: UserDefaults.standard.string(forKey: "usuario")!).getDocuments(){ [self]
            (QuerySnapshot, err) in
            if let err = err{
                print("Error getting documents: \(err)")
            }else{
                information = QuerySnapshot!.documents.first?.data()
                print(information!)
                idDoc = (QuerySnapshot?.documents.first!.documentID)!
                self.setData(data: information)
            }
        }
    }
    
    func setData(data : [String:Any]? ) {
        tfName.text = data!["Nombre"] as? String
        
        let ts = (data!["FechaNacimiento"] as? Timestamp)!
        
        let aDate = ts.dateValue()
        
        dpDateofBirth.setDate(aDate, animated: false)
        
        Sexo.selectedSegmentIndex = (data!["Sexo"] as? Int)!
        
        tfHeight.text = String((data!["Altura"] as? Double)!)
        
        tfWeight.text = String((data!["Peso"] as? Double)!)
        
        tfAddress.text = data!["Direccion"] as? String
        
        tfEmail.text = data!["IDPaciente"] as? String

    }
}

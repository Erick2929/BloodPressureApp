//
//  RecoverViewController.swift
//  Pressura
//
//  Created by alumno on 01/10/22.
//

import UIKit

class RecoverViewController: UIViewController {
    
    @IBOutlet weak var btBack: UIButton!
    
    @IBOutlet weak var tfMail: UITextField!
    
    @IBOutlet weak var btSend: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goBack(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btSendMail(_ sender: UIButton)
    {
        sendMail()
    }
    
    func sendMail()
    {
      //enviar correo a base para mandar el de recuperado
    }

}

//
//  PresionesViewController.swift
//  Pressura
//
//  Created by Alumno on 13/10/22.
//

import UIKit
import FirebaseFirestore


class PresionesViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
            
        @IBOutlet weak var btBack: UIButton!
        
        @IBOutlet var table: UITableView!
        
        var presiones = [Presion]()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            table.dataSource = self
            reloadTable()
        }

        

        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
        {
            let celdas = tableView.dequeueReusableCell(withIdentifier: "celda")!
            celdas.textLabel?.text = "Medida Superior: \(presiones[indexPath.row].medidaSupe). Medida Inferior: \(presiones[indexPath.row].medidaInfe)."
            
            let fechaString = presiones[indexPath.row].fecha
            
            let format = DateFormatter()
            
            format.dateFormat = "HH:mm dd/MM/YYYY "
            
            celdas.detailTextLabel?.text = "\(format.string(from: fechaString))"
            return celdas
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            print(presiones.count)

            return presiones.count
        }
        
        
        @IBAction func goBack(_ sender: UIButton)
        {
            self.dismiss(animated: true, completion: nil)
        }
        

        
        func reloadTable() {
            
                let db = Firestore.firestore()
                
                db.collection("Presion").whereField("IDPaciente", isEqualTo: UserDefaults.standard.string(forKey: "usuario")!).getDocuments(){ [self]
                    (QuerySnapshot, err) in
                    if let err = err{
                        print("Error getting documents: \(err)")
                    }else{
                        guard let _ = QuerySnapshot else{
                            print("Unknown Error")
                            return
                        }
                        for document in QuerySnapshot!.documents{
                            let data = document.data()
                            
                            let ts = (data["Fecha"] as? Timestamp)!
                            
                            let aDate = ts.dateValue()
                            
                            let MedidaSupe = data["MedidaSuperior"] as? Int
                            
                            let MedidaInfe = data["MedidaInferior"] as? Int
                            
                            print(MedidaSupe)
                            
                            let pres = Presion(fecha: aDate, medidaSupe: MedidaSupe!, medidaInfe: MedidaInfe!)
                            presiones.append(pres)
                        }
                        presiones.sort(by: >)
                        table.reloadData()

                        
                    }
                    
                }
            }
    }


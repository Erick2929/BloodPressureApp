//
//  ViewController.swift
//  Pressura
//
//  Created by alumno on 19/09/22.
//

import UIKit
import Firebase
import FirebaseAuth

class RegistroViewController: UIViewController {
    
    

    @IBOutlet weak var tfNombre: UITextField!
    {
        didSet
        {
            tfNombre.tintColor = UIColor.lightGray
            tfNombre.setIcon(UIImage(systemName: "person")!)
        }
    }
    @IBOutlet weak var tfCorreo: UITextField!
    {
        didSet
        {
            tfCorreo.tintColor = UIColor.lightGray
            tfCorreo.setIcon(UIImage(systemName: "envelope.fill")!)
        }
    }
    @IBOutlet weak var tfContra: UITextField!
    {
        didSet
        {
            tfContra.tintColor = UIColor.lightGray
            tfContra.setIcon(UIImage(systemName: "asterisk")!)
        }
    }
    @IBOutlet weak var tfContra2: UITextField!
    {
        didSet
        {
            tfContra2.tintColor = UIColor.lightGray
            tfContra2.setIcon(UIImage(systemName: "asterisk")!)
        }
    }
    
    @IBOutlet weak var btEnviar: UIButton!
    @IBOutlet weak var btLogInSwitch: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    func createUser(email: String, pass: String, completion: @escaping (String)-> Void){
        Auth.auth().createUser(withEmail: email, password: pass){
            (user,error) in
            if let error = error {
                if error.localizedDescription == "The email address is already in use by another account."{
                    self.alarma(mensaje: "Este correo ya esta registrado")
                }
                completion(error.localizedDescription)
                
            }else{
                completion("OK")
                
                let db = Firestore.firestore()
                
                let dateCom = DateComponents(year: 1940, month: 1, day: 1)
                let userCal = Calendar(identifier: .gregorian)
                
                let docData: [String: Any] = [
                    "Altura": 0,
                    "CorreoElectronico": String(self.tfCorreo.text!),
                    "Direccion": "",
                    "FechaNacimiento": userCal.date(from: dateCom)!,
                    "IDPaciente":  String(self.tfCorreo.text!),
                    "Nombre": String(self.tfNombre.text!),
                    "Peso": 0,
                    "Sexo": 0
                ]
                
                var ref: DocumentReference? = nil
                ref = db.collection("Paciente").addDocument(data: docData) { err in
                    if let err = err {
                        print("Error adding document: \(err)")
                    } else {
                        UserDefaults.standard.setValue(self.tfCorreo.text, forKey: "usuario")
                        self.performSegue(withIdentifier: "mainR", sender: nil)
                        print("Document added with ID: \(ref!.documentID)")
                    }
                }
                
                
                            }
        }
    }
    
    func imprimirResultado(result:String){
        print(result)
    }
    
    func alarma(mensaje:String){
        let alerts = UIAlertController(title: "Error", message: mensaje, preferredStyle: .alert)
        let accion = UIAlertAction(title: "OK", style: .cancel)
        alerts.addAction(accion)
        present(alerts, animated: true)
    }
    
    @IBAction func enviado(_ sender: UIButton)
    {
        let nombre = tfNombre.text
        let correo = tfCorreo.text
        let contra = tfContra.text
        let contra2 = tfContra.text
        
        
            if nombre == ""
            {
                alarma(mensaje: "Favor de ingresar su nombre")
            }
       
            else if correo == ""
            {
                alarma(mensaje: "Favor de ingresar su correo")
            }
        
            else if !isValidEmail(correo!){
                alarma(mensaje: "Favor de ingresar un correo valido")
            }
    
            else if contra == ""
            {
            alarma(mensaje: "Favor de ingresar su contraseña")
            }
            else if contra!.count < 10
            {
            alarma(mensaje: "Favor de ingresar una contraseña con minimo 10 characteres")
            }
        
            else if contra2 == ""
            {
                alarma(mensaje: "Favor de confirmar contraseña")
            }
        
        else if tfContra.text != tfContra2.text
        {
            alarma(mensaje: "Las contraseñas ingresadas no coinciden")
        }else{
            createUser(email: correo!, pass: contra!, completion: imprimirResultado)
            
        }
        
       
    }

    
    
}



//
//  RecoverViewController.swift
//  Pressura
//
//  Created by alumno on 01/10/22.
//

import UIKit
import FirebaseAuth


class RecoverViewController: UIViewController {
    
    @IBOutlet weak var btBack: UIButton!
    
    @IBOutlet weak var tfMail: UITextField!
    
    @IBOutlet weak var btSend: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goBack(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
  
    func alarma(mensaje:String)
        {
        let alerts = UIAlertController(title: "Error", message: mensaje, preferredStyle: .alert)
        let accion = UIAlertAction(title: "OK", style: .cancel)
        alerts.addAction(accion)
        present(alerts, animated: true)
        }

    
    @IBAction func btSendMail(_ sender: UIButton)
    {
        
        if !isValidEmail(tfMail.text!){
            alarma(mensaje: "Favor de ingresar un correo valido")
        }else{
            sendMail()
        }
        
    }
    
    func sendMail()
    {
        Auth.auth().languageCode = "es"
        Auth.auth().sendPasswordReset(withEmail: tfMail.text!){ [self]
            (error) in
            if let error = error{
                if error.localizedDescription == "The password is invalid or the user does not have a password."{
                    self.alarma(mensaje: "El correo o la contraseña ingresada estan incorrectas")
                }
                
            }else{
                
                let alerts = UIAlertController(title: "Confirmado", message: "Se ha enviado un correo para poder reiniciar su contraseña de la cuenta \(tfMail.text!).", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .default) { action in
                    self.dismiss(animated: true)
                }
                alerts.addAction(accion)
                present(alerts, animated: true)
            
            }
            
        }
    }

}

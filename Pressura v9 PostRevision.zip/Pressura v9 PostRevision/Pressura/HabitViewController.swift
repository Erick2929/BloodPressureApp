//
//  HabitViewController.swift
//  Pressura
//
//  Created by alumno on 10/10/22.
//

import UIKit
import Firebase

class HabitViewController: UIViewController {
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {

    return UIInterfaceOrientationMask.portrait

    }
    override var shouldAutorotate: Bool {

    return false

    }

    @IBOutlet weak var slDieta: UISlider!
    
    @IBOutlet weak var slEjercicio: UISlider!
    
    @IBOutlet weak var slMeds: UISlider!
    
    @IBOutlet weak var btEnviar: UIButton!
    
    @IBOutlet weak var btBack: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func enviarDatos(_ sender: UIButton)
    {
        
        let db = Firestore.firestore()
        
        let now = Date()
        let stamp = Timestamp(date: now)
        
        let docData: [String: Any] = [
            "Ejercicio": ceil(slEjercicio.value*100),
            "Fecha": stamp,
            "IDPaciente": UserDefaults.standard.string(forKey: "usuario")!,
            "Medicamentos":  ceil(slMeds.value*100),
            "RegimenAlimenticio": ceil(slDieta.value*100)
        ]
        
        var ref: DocumentReference? = nil
        ref = db.collection("Habitos").addDocument(data: docData) { err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(ref!.documentID)")
                self.dismiss(animated: true, completion: nil)
                }
            }
        
    }
    
    @IBAction func goBack(_ sender: UIButton)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    


}

//
//  ViewController.swift
//  Pressura
//
//  Created by alumno on 19/09/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tfNombre: UITextField!
    {
        didSet
        {
            tfNombre.tintColor = UIColor.lightGray
            tfNombre.setIcon(UIImage(systemName: "person")!)
        }
    }
    @IBOutlet weak var tfCorreo: UITextField!
    {
        didSet
        {
            tfCorreo.tintColor = UIColor.lightGray
            tfCorreo.setIcon(UIImage(systemName: "envelope.fill")!)
        }
    }
    @IBOutlet weak var tfContra: UITextField!
    {
        didSet
        {
            tfContra.tintColor = UIColor.lightGray
            tfContra.setIcon(UIImage(systemName: "asterisk")!)
        }
    }
    @IBOutlet weak var tfContra2: UITextField!
    {
        didSet
        {
            tfContra2.tintColor = UIColor.lightGray
            tfContra2.setIcon(UIImage(systemName: "asterisk")!)
        }
    }
    
    @IBOutlet weak var btEnviar: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func enviado(_ sender: UIButton)
    {
        let nombre = tfNombre.text
        let correo = tfCorreo.text
        let contra = tfContra.text
        let contra2 = tfContra.text
        
        
            if nombre == ""
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de ingresar su nombre", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }
       
            if correo == ""
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de ingresar su correo", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }
    
            if contra == ""
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de ingresar su contraseña", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }
        
            if contra2 == ""
            {
                let alerts = UIAlertController(title: "Error", message: "Favor de confirmar contraseña", preferredStyle: .alert)
                let accion = UIAlertAction(title: "OK", style: .cancel)
                alerts.addAction(accion)
                present(alerts, animated: true)
            }
        
        else if tfContra.text != tfContra2.text
        {
            let alerts = UIAlertController(title: "Error", message: "Las contraseñas ingresadas no coinciden", preferredStyle: .alert)
            let accion = UIAlertAction(title: "OK", style: .cancel)
            alerts.addAction(accion)
            present(alerts, animated: true)
        }
        
       
    }

    
    
}

extension UITextField
{
    func setIcon(_ image: UIImage)
    {
        let iconView = UIImageView(frame: CGRect(x: 10, y: 5, width: 20, height: 20))
        iconView.image = image
        
        let iconContainerView: UIView = UIView(frame: CGRect(x: 20, y: 0, width: 30, height: 30))
        iconContainerView.addSubview(iconView)
        
        leftView = iconContainerView
        leftViewMode = .always
    }
}

